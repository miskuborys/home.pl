Platforma BotAPI pozwala na szybkie i proste tworzenie botów w sieci Gadu-Gadu. Wystawia zestaw funkcji za pomocą protokołu HTTP, które umożliwiają odbieranie i wysyłanie wiadomości poprzez skrypt/program stworzony przez użytkownika BotAPI.

Więcej informacji na http://boty.gg.pl/
